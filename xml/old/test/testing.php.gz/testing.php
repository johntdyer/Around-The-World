<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8">
	<title>testing</title>
	<script type="text/javascript" src="http://www.google.com/jsapi?hl=en&amp;key=ABQIAAAAmT4HTUYKdvGqcdPCdYMIchRI67tzt4RgYf9_Oo6dkCFUpwfw1BS0ItGt6lkqTLG-jMDGkI63EPoFRw"></script>
	<script type="text/javascript" charset="utf-8">
		google.load("jquery", "1.4.2");
	</script>
<?
include ('lib/functions.php');

if(isset($_GET['sessionID'])){

$sessionID=$_REQUEST['sessionID'];
$flashPhone=$_REQUEST['flashPhone'];
$playerName=$_REQUEST['playerName'];
$phoneNumber=$_REQUEST['phoneNumber'];

//1C84D367-E5CA-655A-5FD1-F4B4411B1F54
?>

<script type="text/javascript" charset="utf-8">		
			$.get('api/api.php', { callerid: '4074181800',sessionID: '<? echo $sessionID; ?>',phoneNumber: '<? echo $phoneNumber; ?>',playerName: '<?echo $playerName; ?>',flashPhone: '<?echo $flashPhone; ?>',location: 'Atlanta',action: 'update'} );						
</script>
<?
}
#echo updateLocation('Atlanta','9A424E5C-3A5D-662B-7847-D9E0F90F');
#print_r(updateLocation('9A424E5C-3A5D-662B-7847-D9E0F90F','Orlando'));
#echo "|" . recordExists('9A424E5C-3A5D-662B-7847-D9E0F90F');
?>
</head>
