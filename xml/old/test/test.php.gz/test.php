<?
include ('../lib/functions.php');
?>
<form action="../api/api.php" method="get" accept-charset="utf-8">
	<input type="hidden" name="sessionID" value="123ad4098asdalkja098a0sdfd980">
	<select name="location" id="location" size="5">
		<option value="london">london</option>
		<option value="beijing">Beijing</option>
		<option value="atlanta">Atlanta</option>
		<option value="orlando">Orlando</option>
		<option value="vegas">Las Vegas</option>
	</select>
	

	<p><input type="submit" value="Continue &rarr;"></p>
</form>
